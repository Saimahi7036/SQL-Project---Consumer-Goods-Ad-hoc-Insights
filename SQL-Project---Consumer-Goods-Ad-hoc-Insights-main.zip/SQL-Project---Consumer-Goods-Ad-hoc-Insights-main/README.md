# SQL-Project---Consumer-Goods-Ad-hoc-Insights
This is a Data Analytics project I have done using SQL as part of Codebasics SQL Project Challenge.
